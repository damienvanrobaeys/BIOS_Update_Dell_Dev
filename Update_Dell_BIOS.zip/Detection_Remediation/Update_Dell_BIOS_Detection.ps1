#**************************************************************
# Part to fill
#**************************************************************
$BIOS_Delay_Days = 90	
#**************************************************************
# Part to fill
#**************************************************************								


$ddlCategoryWeb =[xml]@'
<select id="ddl-category" class="w-100 form-control custom-select drivers-select">
    <option value="BI"> BIOS </option>
</select>
'@

$Script:dictionaryCategory = @{}
$ddlCategoryWeb.select.option | Foreach {$Script:dictionaryCategory[$_.value] = $_.'#text'.Trim()}

$Script:ddlCategoryWeb =[xml]@'
<select id="operating-system" class="w-100 form-control custom-select drivers-select">
	<option value="BIOSA">BIOS</option>
</select>
'@


Class Dell 
{

    
    Static hidden [String]$_vendorName = "Dell"
    hidden [Object[]] $_deviceCatalog 
    hidden [Object[]] $_deviceImgCatalog 

    # Contructor
    Dell()
    {
        $this._deviceCatalog = [Dell]::GetDevicesCatalog()
        $this._deviceImgCatalog = [Dell]::GetDeviceImgCatalog()
        
    }



    #####################################################################
    # Get all Data from DELL (Gz format)
    #####################################################################
    # https://www.dell.com/support/components/eula/en-us/eula/api
    
    Static hidden [Object[]]GetDevicesCatalog()
    {
        
        # --------------------------------------------------------------------------------------------------------
        # Truncated Output exemple
        # PN                                         PC                                   
        # --                                         --                                   
        # Latitude 5290                              latitude-12-5290-laptop              
        # Latitude 5290 2-in-1                       latitude-12-5290-2-in-1-laptop       
        # Latitude 5300                              latitude-13-5300-laptop              
        # Latitude 5300 2-in-1                       latitude-13-5300-2-in-1-laptop    
        # --------------------------------------------------------------------------------------------------------

        $result = Invoke-WebRequest -Uri "https://www.dell.com/support/home/en-us/api/catalog/autosuggest" -Headers @{
            "method"="GET"
            "authority"="www.dell.com"
            "scheme"="https"
            "cache-control"="max-age=0"
            "upgrade-insecure-requests"="1"
            "accept"="text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
            "sec-fetch-site"="none"
            "sec-fetch-mode"="navigate"
            "sec-fetch-user"="?1"
            "sec-fetch-dest"="document"
            "accept-encoding"="gzip, deflate, br"
            "accept-language"="en-US,en;q=0.9"
        }

        $jsonObject = $($result.Content | ConvertFrom-Json) | Select-Object -Property "PN","PC"
        return $jsonObject
    
    }


    Static hidden [Object[]] GetDeviceImgCatalog()
    {
        
        # --------------------------------------------------------------------------------------------------------
        # This object return another object with Product ID and Image URL associated
        # 
        # --------------------------------------------------------------------------------------------------------
        $gzProductContent = Invoke-WebRequest -Uri "https://downloads.dell.com/Published/data/Products.gz" -Headers @{
            "method"="GET"
            "authority"="www.dell.com"
            "scheme"="https"
            "cache-control"="max-age=0"
            "upgrade-insecure-requests"="1"
            "accept"="text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
            "sec-fetch-site"="none"
            "sec-fetch-mode"="navigate"
            "sec-fetch-user"="?1"
            "sec-fetch-dest"="document"
            "accept-language"="en-US,en;q=0.9"
            }

        # Convert Stream Data to viewable Content 
        $data = $gzProductContent.Content
        $memoryStream = [System.IO.MemoryStream]::new()
        $memoryStream.Write($data, 0, $data.Length)
        $memoryStream.Seek(0,0) | Out-Null


        $gZipStream = [System.IO.Compression.GZipStream]::new($memoryStream, [System.IO.Compression.CompressionMode]::Decompress)
        $streamReader = [System.IO.StreamReader]::new($gZipStream)
        $xmlModelInputRaw = $streamReader.readtoend()  


        # ######################################################
        # Parse content 
        # ######################################################

        $xmlModelInput = New-Object -TypeName System.Xml.XmlDocument
        $xmlModelInput.LoadXml($xmlModelInputRaw)

        $productCatalogObj = $xmlModelInput.Catalog.Product.Where({$_.Image -ne ""}) | Select-Object -Property ID,Image


        # Works but too slooooowwww ..... keep for later
        #  $jsonObject =  $autoSuggestCatalog |% { 
        #    foreach ($product in $productCatalogObj) {
        #        if ($_.PC -eq $product.Id) {
        #            [pscustomobject]@{Name=$_.PN;ProductGuid=$_.PC;Image=$product.Image}
        #        }
        #    }
        #}
           
        return $productCatalogObj

    }


    [Object[]] GetImageTable()
	{
        return $this._deviceImgCatalog
    }



	[Object[]] GetText($userInputModel)
	{
		#$userSearchResult = $this._deviceCatalog | Where-Object {($_.PN -match $userInputModel)} 
		$userSearchResult = @()
	
		foreach($obj in $this._deviceCatalog){
            if($obj.PN -match $userInputModel){
                $userSearchResult += $obj
            }
        }
		
		return $userSearchResult
	}


    #########################################################################
    # Find Model Based on User input
    #########################################################################

    [Object[]]FindModel($userInputModel)
    {

        # --------------------------------------------------------------------------------------------------------
        # return an Array of object of type: 
        # Name                                       Guid                                  Path                                           Image                 
        # ----                                       ----                                  ----                                           -----                 
        # Latitude 5300                              latitude-13-5300-laptop               /product/latitude-13-5300-laptop               https://i.dell.com/is/ima...
        # Latitude 5300 2-in-1                       latitude-13-5300-2-in-1-laptop        /product/latitude-13-5300-2-in-1-laptop        https://i.dell.com/is/ima...
        # --------------------------------------------------------------------------------------------------------

        $SearchResultFormatted = @()
        #$ImgCatalog = $this._deviceCatalog
		$userSearchResult = $this._deviceCatalog.Where({$_.PN -match $userInputModel}) 
	
		foreach($obj in $userSearchResult){
			 
            $SearchResultFormatted += [PSCustomObject]@{
                Name=$obj.PN;
                Guid=$obj.PC;
                Path="/product/$($obj.PC)";
                Image= $(
                     #   $obj = $ImageTable.Where({$_.Id -eq $obj.PC})
                     $obj = $this._deviceImgCatalog.Where({$_.Id -eq $obj.PC})
                        if($obj.Image){
                            "https:$($obj.Image)"
                        }else{
                            'https://i.dell.com/is/image/DellContent/content/dam/global-site-design/product_images/esupport/icons/esupport-blank-space-v2.png'
                        }
                    )
            } 
        }



        return $SearchResultFormatted

    }

    
    #########################################################################
    # Get Product URL
    #########################################################################

    Static hidden [string] GetModelHomepageURL($devicePath)
    {

        $Homepage = "https://www.dell.com/support/home/en-us/product-support/$($devicePath)"
        return $Homepage

    }


    #########################################################################
    # Get Json Data for a Dell Device form its GUID
    #########################################################################

    hidden [Object[]] GetModelWebResponse($modelGUID)
    {

        #  ==== For Download  =======
        $modelGzURL = "https://downloads.dell.com/published/data/drivers/$($ModelGUID).gz"

        $gzContent = Invoke-WebRequest -Uri $modelGzURL -Headers @{
          "method"="GET"
          "authority"="www.dell.com"
          "scheme"="https"
          "cache-control"="max-age=0"
          "upgrade-insecure-requests"="1"
          "accept"="text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
          "sec-fetch-site"="none"
          "sec-fetch-mode"="navigate"
          "sec-fetch-user"="?1"
          "sec-fetch-dest"="document"
          "accept-language"="en-US,en;q=0.9"
         }

        # === Convert Stream Data to viewable Content =====
        $data = $gzContent.Content
        $memoryStream = [System.IO.MemoryStream]::new()
        $memoryStream.Write($data, 0, $data.Length)
        $memoryStream.Seek(0,0) | Out-Null

        $gZipStream = [System.IO.Compression.GZipStream]::new($memoryStream, [System.IO.Compression.CompressionMode]::Decompress)
        $streamReader = [System.IO.StreamReader]::new($gZipStream)
        $xmlModelInputRaw = $streamReader.readtoend()  

        # === Parse content =======================
        $xmlModelInput = New-Object -TypeName System.Xml.XmlDocument
        $xmlModelInput.LoadXml($xmlModelInputRaw)

        return $xmlModelInput


    }

	
	#########################################################################
    # Get All Supported OS
    #########################################################################

    hidden [Object[]]GetAllSupportedOS($webresponse)
    {
		
		# Hard Coded until I find Dell Table
        $operatingSystemObj= $Script:ddlCategoryWeb.select.option | Foreach { [PSCustomObject]@{ Name = $_.'#text'.Trim(); Value = $_.value}}
		return $operatingSystemObj

	}

    #########################################################################
    # Load All Drivers to exploitable format
    #########################################################################

    hidden [Object[]]LoadDriversFromWebResponse($webresponse)
    {

        # Webresponse is a xml
        $DownloadItemsObj = [Collections.ArrayList]@()

        if($webresponse.Product.Drivers){

            $DownloadItemsRaw = $webresponse.Product.Drivers.Driver | Sort-Object -Property Title
            $DownloadItemsRawGrouped = $DownloadItemsRaw | Group-Object -Property Title
            
            ForEach ($Itemgroup in $DownloadItemsRawGrouped){
                $item = $null
                # Select only the latest version if multiple
                if($Itemgroup.Group.Count -ge 2){
                    $maximum = 0
                    foreach($vendorVer in $Itemgroup.Group){
                        if($vendorVer.VendorVersion -gt $maximum){
                            $maximum = $vendorVer.VendorVersion
                            #Write-Host $maximum
                            $item = $vendorVer
                        }
                    }
                }else{
                    $item = $Itemgroup.Group
                }

                # ==== Get the exe,zip ... ==========
                [Array]$ExeFiles = $item.File 

                $current = [PSCustomObject]@{
                    Title =$item.Title;
                    Category=$Script:dictionaryCategory[$item.Category];
                    Class=$item.Type;
                    OperatingSystemKeys=$item.OS.Split(",");

                    Files= [Array]($ExeFiles | ForEach-Object { 
                        if($_){
                            [PSCustomObject]@{
                                IsSelected=$false;
                                ID=$item.ID;
                                Name=$_.FileName.Split('/')[-1];
                                Size="$([Math]::Round($_.Size/1MB, 2)) MB";
                                Type=$item.Type;
                                Version=$item.VendorVersion
                                URL="https://dl.dell.com/$($_.FileName)";
                                Priority=$item.Importance ;
                                Date=$item.LastUpdateDate
                            }
                        }
                    })
                }

                $DownloadItemsObj.Add($current) | Out-Null
        
            }

        }

        return $DownloadItemsObj



    }




	#########################################################################
    # Prepare Drivers Download
    #########################################################################

    hidden [Object[]] PrepareDriversGroupDownload($selectedDrivers)
	{
		
		$GroupsByCategory = $selectedDrivers | Group-Object -Property Category
        $cat = $null

        $PreparedDownloadList = [Collections.ArrayList]@()

        foreach ($category in $GroupsByCategory){
       
            # Create category folder 
            switch ($category.Name) {
               "Dell Data Security"               {$cat = "Security"; break}
               "Docks/Stands"                     {$cat = "Docks"; break}
               "Modem/Communications"             {$cat = "Communications"; break}
               "Mouse, Keyboard & Input Devices"  {$cat = "Input"; break}
               "Serial ATA"                       {$cat = "Storage"; break}
               default                            {$cat = $category.Name ; break}
            }


            foreach($item in $category.Group){  
					
		        [Array]$item.Files | ForEach-Object {
                    
                    if($_.IsSelected){
    
                        $current = [PSCustomObject]@{
                            DownloadGroup = $cat;
                            DownLoadID    = $_.ID;
                            DownloadURL   = $_.URL;
                            DownloadSize  = $_.Size
                        }

                        $PreparedDownloadList.Add($current) | Out-Null
                    }

                }
               
            }
			
        }

		return $PreparedDownloadList

    }



    #########################################################################
    # Download Selected Driver of the model 
    #########################################################################

    [String] DownloadDriver($url ,$DownloadFolder )
    {

        $var = 'Success'
		$client = [System.Net.WebClient]::new()
				
        try {
					
            $sourceFileName = $url.SubString($url.LastIndexOf('/')+1)            
            $targetFileName = "$DownloadFolder\$sourceFileName"  

            Write-Host $targetFileName    
	
            $client.DownloadFile($url, $targetFileName)  
            #$client.DownloadFileAsync($UrlSelected, $targetFileName) 
                    
        } 
        Catch { 
            $var = "Error:  $($_.Exception.Message)" 
        }
		Finally{
					
			$client.dispose()
		}
     
        return $var
    }


    #########################################################################
    # Extract All DELL Drivers in DownloadFolder
    #########################################################################

    [String] ExtractDriver($file, $folderPath)
    {
    
		$output = ""


		# --------------------------------------------------------------------------------------------------------
		# buffer overflow in case of large files in output // RedirectStandardOutput = false
		# https://stackoverflow.com/questions/139593/processstartinfo-hanging-on-waitforexit-why
		# --------------------------------------------------------------------------------------------------------


		$pStartInfo = [System.Diagnostics.ProcessStartInfo]::new()
		$pStartInfo.RedirectStandardError = $true
		$pStartInfo.RedirectStandardOutput = $false  
		$pStartInfo.UseShellExecute = $false
		$pStartInfo.CreateNoWindow = $true
		$pStartInfo.FileName = $Script:7zipExtractExe
		# $pStartInfo.Arguments = "x $file Production -o""$folderPath"" -r -y"
		$pStartInfo.Arguments = "x ""$file"" -o""$folderPath"" -r -y"
	
		$process = [System.Diagnostics.Process]::new()
		$process.StartInfo = $pStartInfo
		$process.Start() | Out-Null
		$process.WaitForExit()
		
		If($process.ExitCode -ne 0){
			$stderr = $process.StandardError.ReadToEnd()
			$output = "Exit code: $($process.ExitCode). Error: $stderr" 
		}
		Else{
			$output =  "Extract Succesful." 
		}

       
		return $output


    }

    #########################################################################
    # Get CAB Content 
    #########################################################################

    [Object[]] ExtractCabInfosOfModel($DriversModeldatas){
        
        $allCABType = $DriversModeldatas.Where({$_.Title -match 'Driver Pack'})

        if($allCABType.Count -gt 0){
            return $allCABType
        }else{
            return $null
        }
        
    }
 
    #########################################################################
    # Get CAB Content 
    #########################################################################

    [Object[]] GetCabDriversContent($urlCabReleaseNote){


        #$urlCabReleaseNote = "https://dl.dell.com/FOLDER06609809M/1/5310-win10-A03-RJRT2.html"

        $cabReleaseNote =  Invoke-WebRequest -Uri $urlCabReleaseNote -Headers @{
        "method"="GET"
          "authority"="dl.dell.com"
          "scheme"="https"
          "pragma"="no-cache"
          "cache-control"="no-cache"
          "upgrade-insecure-requests"="1"
          "accept"="text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9"
          "sec-fetch-site"="none"
          "sec-fetch-mode"="navigate"
          "sec-fetch-user"="?1"
          "sec-fetch-dest"="document"
          "accept-encoding"="gzip, deflate, br"
          "accept-language"="en-US,en;q=0.9"
        }


        $ReleaseNoteString = $cabReleaseNote.ParsedHtml.body.innerText
        $tab = [Array]$cabReleaseNote.ParsedHTML.GetElementsByTagName("tr")

        $result = @()

        foreach ($elem in ($tab[0] | Select -Skip 1 )){
            $result += [PScustomobject]@{
                Category          = $elem.cells[0].innerText;
                ReleaseID         = $elem.cells[1].innerText;
                DeviceDescription = $elem.cells[2].innerText;
                DellVersion       = $elem.cells[3].innerText;
                VendorVersion     = $elem.cells[4].innerText
            }
        }


        return $result


    }


}

$BIOS_Version = gwmi win32_bios
# $BIOS_Maj_Version = $BIOS_Version.SystemBiosMajorVersion 
# $BIOS_Min_Version = $BIOS_Version.SystemBiosMinorVersion 
$Get_Current_BIOS_Version = $BIOS_Version.SMBIOSBIOSVersion

$RunspaceScopeVendor = [Dell]::new()
$Get_Current_Model = ((gwmi win32_computersystem).Model)
$Search_Model = $RunspaceScopeVendor.FindModel("$Get_Current_Model")
$Get_GUID = $Search_Model.Guid 

$wbrsp 	= $RunspaceScopeVendor.GetModelWebResponse("$Get_GUID")
$OSCatalog = $RunspaceScopeVendor.GetAllSupportedOS($wbrsp) 
$DriversModeldatas 	= $RunspaceScopeVendor.LoadDriversFromWebResponse($wbrsp) 
# $DriversModeldatas | out-gridview
$DriversModelDatasForOsType = [Array]($DriversModeldatas | Where-Object {($_.Title -like "*System BIOS*" )} )
$Get_BIOS_Update = $DriversModelDatasForOsType.files  | Where {$_ -like "*EXE*"}
$Get_New_BIOS_Version = $Get_BIOS_Update.version						
$Get_New_BIOS_URL = $Get_BIOS_Update.URL
$Get_New_BIOS_Date = $Get_BIOS_Update.Date

[int]$Get_New_BIOS_Date_month = $Get_New_BIOS_Date.split("/")[0]
If($Get_New_BIOS_Date_month -lt 10)
{
	$Get_New_BIOS_Date = "0$Get_New_BIOS_Date"
}
$Get_Converted_BIOS_Date = [Datetime]::ParseExact($Get_New_BIOS_Date, 'MM/dd/yyyy', $null)	


$BIOS_Update_File_Name = "BIOSUpdate_$Get_Current_Model"
$BIOS_Update_Folder = "C:\Windows\Temp\BIOS_Update"

new-item $BIOS_Update_Folder -Force -Type Directory | out-null
$Get_New_BIOS_URL | out-file "$BIOS_Update_Folder\BIOS_URL.txt"


$Get_Current_Date = get-date
$Diff_LastBIOS_and_Today = $Get_Current_Date - $Get_Converted_BIOS_Date
# $BIOS_Delay_Days = 90									
$Diff_in_days = $Diff_LastBIOS_and_Today.Days
If(($Diff_in_days) -gt $BIOS_Delay_Days)
	{		
		write-output "Plus de 90 jours ($Diff_in_days)"
		# EXIT 1
	}
Else
	{		
		write-output "Moins de 90 jours ($Diff_in_days)"
		# EXIT 0												
	}													
