﻿#******************************************************************************
# Part to fill
#******************************************************************************
# Information to fill if you need an Azure app to contact Azure Key Vault
$TenantID = ""
$App_ID = ""
$ThumbPrint = ""

# Information to fill if you need to use Azure Key Vault
$vaultName = "SDVault"
$PasswordName = "NewPassword" 
#******************************************************************************
# Part to fill
#******************************************************************************		


$TenantID = "3e7df579-cc70-46fb-9b1b-bf112b5b21ff"
$App_ID = "f410b6d3-8954-4c3e-bc88-8a8661056884"
$ThumbPrint = "36DC7BAB2B703E7930BB53BA7C4B80BCB85070E3"

$Get_Current_Model = ((gwmi win32_computersystem).Model)
$User_Continue_Process_File = "$BIOS_Update_Folder\BIOS_Update_Continue.txt"
$Extract_Folder_Path = "$BIOS_Update_Folder\BIOS_Extract"
$WPF_Warning_Export_Folder = "$BIOS_Update_Folder\WPF_Warning"
$Log_File = "$env:SystemDrive\Windows\Debug\Remediate_Update_BIOS_$Get_Current_Model.log"
$BIOS_Update_File_Name = "BIOSUpdate_$Get_Current_Model"
$BIOS_Update_Folder = "C:\Windows\Temp\BIOS_Update"

$Global:Current_Folder = split-path $MyInvocation.MyCommand.Path

If(!(test-path $Log_File)){new-item $Log_File -type file -force}
If(!(test-path $Extract_Folder_Path)){new-item $Extract_Folder_Path -type Directory -force}

Function Write_Log
	{
		param(
		$Message_Type,	
		$Message
		)
		
		$MyDate = "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)		
		Add-Content $Log_File  "$MyDate - $Message_Type : $Message"		
		write-host  "$MyDate - $Message_Type : $Message"		
	}
	
# Importing Dell module to check if BIOS password is configured
$Modules_Path = "$BIOS_Update_Folder\WPF_Warning\Modules"

# Get-Childitem $Modules_Path -Recurse | Unblock-file
# $DellBIOSProvider_Module = "$Modules_Path\DellBIOSProvider"
# $DellBIOSProvider_Module = "D:\Upload_BIOS\Dell\Tool_Sources_Dell\Sources\Modules\DellBIOSProvider"
# Write_Log -Message_Type "INFO" -Message "Importing Dell module"																		
# Try
	# {
		# [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
		# import-module "$DellBIOSProvider_Module" -ErrorAction Stop	
	# }
# Catch
	# {
		# Write_Log -Message_Type "ERROR" -Message "Importing Dell module"	
		# Write_Log -Message_Type "ERROR" -Message $error[0]		
		# EXIT
	# }


# If(!(Get-PackageProvider | where {$_.Name -eq "Nuget"}))
	# {			
		# Write_Log -Message_Type "SUCCESS" -Message "The package Nuget is not installed"							
		# Try
			# {
				# Write_Log -Message_Type "SUCCESS" -Message "The package Nuget is being installed"						
				# [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
				# Install-PackageProvider -Name Nuget -MinimumVersion 2.8.5.201 -Force -Confirm:$False | out-null								
				# Write_Log -Message_Type "SUCCESS" -Message "The package Nuget has been successfully installed"	
				# $Is_Nuget_Installed = $True						
			# }
		# Catch
			# {
				# Write_Log -Message_Type "ERROR" -Message "The package Nuget is being installed"	
				# Break
			# }
	# }
# Else
	# {
		# Write_Log -Message_Type "INFO" -Message "The package Nuget is already installed"	
		# $Is_Nuget_Installed = $True	
	# }

# If($Is_Nuget_Installed -eq $True)
	# {
		# Write_Log -Message_Type "INFO" -Message "Checkig module DellBIOSProvider"  
		# If (!(Get-Module DellBIOSProvider -listavailable)) 
			# {
				# Write_Log -Message_Type "INFO" -Message "DellBIOSProvider is not installed"  	
				# Try
					# {
						# Install-Module DellBIOSProvider -ErrorAction Stop
						# Write_Log -Message_Type "INFO" -Message "DellBIOSProvider has been installed"  						
					# }
				# Catch	
					# {
						# Write_Log -Message_Type "ERROR" -Message $error[0]		
						# EXIT					
					# }	
			# }
		# Else
			# {
				# Try
					# {
						# Import-Module DellBIOSProvider -ErrorAction Stop
						# Write_Log -Message_Type "INFO" -Message "DellBIOSProvider has been imported"  						
					# }
				# Catch	
					# {
						# Write_Log -Message_Type "ERROR" -Message $error[0]		
						# EXIT					
					# }			
			# }	
	# }
# Else
	# {
		# Write_Log -Message_Type "INFO" -Message "DellBIOSProvider is already installed"  	
	# }	
#**************************************************************
# Part to fill
#**************************************************************
$BIOS_Delay_Days = 90	
#**************************************************************
# Part to fill
#**************************************************************		

Write_Log -Message_Type "ERROR" -Message "Checking BIOS password"	
$BIOS_Password_Status_File = "$Modules_Path\IsPasswordSet.txt"				
If(test-path $BIOS_Password_Status_File)
	{
		$IsPasswordSet = Get-Content $BIOS_Password_Status_File
	}
Else
	{
		Write_Log -Message_Type "ERROR" -Message "File not found: $test-path $BIOS_Password_Status_File"	
		EXIT
	}

If($IsPasswordSet -eq $true)
	{
		Write_Log -Message_Type "INFO" -Message "A BIOS password is configured"																			
		Write_Log -Message_Type "INFO" -Message "Getting BIOS password from AZure Key Vault"																		
		$AzAccounts_Module = "$Modules_Path\Az.Accounts"
		$AzKeyVault_Module = "$Modules_Path\Az.KeyVault"

		Write_Log -Message_Type "INFO" -Message "Importing AZ modules"	

		Try
			{
				import-module $AzAccounts_Module 
				import-module $AzKeyVault_Module 	
				Write_Log -Message_Type "SUCCESS" -Message "Importing AZ modules"		
			}
		Catch
			{
				Write_Log -Message_Type "ERROR" -Message "Importing AZ modules"		
				EXIT
			}


		Write_Log -Message_Type "INFO" -Message "Connecting to Key Vault"	
		Try
			{
				Connect-AzAccount -tenantid $TenantID -ApplicationId $App_ID -CertificateThumbprint $ThumbPrint 
				Write_Log -Message_Type "SUCCESS" -Message "Connecting to Key Vault"	
			}
		Catch
			{
				Write_Log -Message_Type "ERROR" -Message "Connecting to Key Vault"	
				EXIT
			}


		Write_Log -Message_Type "INFO" -Message "Getting secret"	
		Try
			{
				# $secret = (Get-AzKeyVaultSecret -vaultName "SDVault" -name "NewPassword") | select *
				$secret = (Get-AzKeyVaultSecret -vaultName $vaultName -name $PasswordName) | select *				
				$Get_My_Secret = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secret.SecretValue) 
				$My_Secret = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($Get_My_Secret) 	
				Write_Log -Message_Type "SUCCESS" -Message "Getting secret"	
			}
		Catch
			{
				Write_Log -Message_Type "ERROR" -Message "Getting secret"	
				EXIT
			}
	}
Else
	{
		Write_Log -Message_Type "INFO" -Message "No BIOS password configured"																			
	} 

				
Write_Log -Message_Type "INFO" -Message "The user validate the update process"																		

# BIOS Update installer
$Installer = "$BIOS_Update_File_Name.exe"	
# Path of the BIOS installer
$Install_Path = "$BIOS_Update_Folder\$Installer"	
# BIOS Update log name
$BIOS_Update_Log_File = "Dell_BIOS_Update.log"	
# BIOS Update log path
$Log_Path = "C:\Windows\Debug\$BIOS_Update_Log_File"	
# BIOS Password
# You can type the password in clear if you're not afraid
# $Password = "toto"	
# Or you can getting password from Key Vault
$Password = $My_Secret									
# BIOS Update installer silent switch
If($IsPasswordSet -eq $true)
	{
		$Silent_Switch = "/s /f /l=$Log_Path /p=$Password /bls"						
	}
Else
	{
		$Silent_Switch = "/s /f /l=$Log_Path /bls"							
	}
Write_Log -Message_Type "INFO" -Message "Mise à jour du BIOS"	
If(test-path $Install_Path)
	{
		Try
			{
				Write_Log -Message_Type "INFO" -Message "Updating BIOS"									
				Write_Log -Message_Type "INFO" -Message "Path of the update: $Install_Path"	
				
				$Update_Process = Start-Process -FilePath $Install_Path  -ArgumentList $Silent_Switch -PassThru -Wait
				If(($Update_Process.ExitCode) -eq 2) 
					{
						Write_Log -Message_Type "INFO" -Message "Checking update state in log file"																				
						If(test-path $Log_Path)
							{
								$Check_BIOSUpdate_Status_FromLog = ((Get-content $Log_Path | where-object { $_ -like "*BIOS flash finished at*"}) -ne "")		
								If($Check_BIOSUpdate_Status_FromLog -ne $null)
									{
										Write_Log -Message_Type "SUCCESS" -Message "Updating BIOS"															
										Write_Log -Message_Type "INFO" -Message "Reboot pending"	
										start-process -WindowStyle hidden powershell.exe "$WPF_Warning_Export_Folder\Restart_Computer.ps1" -Wait	
										# Remove-item $BIOS_Update_Folder -Force -Recurse
										Break		
									}
								Else
									{									
										Write_Log -Message_Type "ERROR" -Message "Updating BIOS"		
										Break
									}
							}
						Else
							{
								Write_Log -Message_Type "SUCCESS" -Message "File not found: $Log_Path"												
							}
					}	
				Else
					{
						Write_Log -Message_Type "ERROR" -Message "Updating BIOS"	
						Break						
					}										
			}
		Catch
			{
				Write_Log -Message_Type "ERROR" -Message "Updating BIOS"	
				Break						
			}			
	}
Else
	{
		Write_Log -Message_Type "INFO" -Message "BIOS installer not found: $Install_Path"						
	}
